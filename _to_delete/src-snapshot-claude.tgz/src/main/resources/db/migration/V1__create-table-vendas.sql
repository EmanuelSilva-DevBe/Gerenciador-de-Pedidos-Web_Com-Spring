CREATE TABLE VENDA(
    id UUID DEFAULT gen_rabdom_uuid() PRIMARY KEY,
    valor_total NUMERIC(10,2)
);