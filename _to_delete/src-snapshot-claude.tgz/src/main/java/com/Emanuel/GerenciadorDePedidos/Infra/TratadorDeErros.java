package com.Emanuel.GerenciadorDePedidos.Infra;

import jakarta.persistence.EntityNotFoundException;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.List;

@RestControllerAdvice //Indica que é uma classe específica para tratar erros
public class TratadorDeErros {

    @ExceptionHandler(EntityNotFoundException.class)
    public ResponseEntity trata404(){
        return ResponseEntity.notFound().build();
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity trata400(MethodArgumentNotValidException ex){
        var erros = ex.getFieldErrors();

        var errosFormatados = erros.stream()
                .map(DadosErroValidacao::new)
                .toList();


        return ResponseEntity.badRequest().body(errosFormatados);
    }

    public record DadosErroValidacao(String campo, String mensagem){
        public DadosErroValidacao(FieldError err){
            this(err.getField(), err.getDefaultMessage());
        }
    }

}

